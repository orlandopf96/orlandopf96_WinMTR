//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by WinMTR.rc
//
#define IDD_WINMTR_DIALOG               102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDS_STRING_SB_NAME              104
#define IDS_STRING_SB_PING              105
#define IDS_STRING_CLEAR_HISTORY        106
#define IDR_MAINFRAME                   128
#define IDD_DIALOG_OPTIONS              129
#define IDD_DIALOG_LICENSE              130
#define IDD_DIALOG_PROPERTIES           131
#define IDD_DIALOG_HELP                 132
#define IDC_EDIT_HOST                   1000
#define IDC_LIST_MTR                    1001
#define ID_RESTART                      1002
#define ID_OPTIONS                      1003
#define IDC_EDIT_INTERVAL               1004
#define ID_CTTC                         1004
#define IDC_EDIT_SIZE                   1005
#define ID_CHTC                         1005
#define IDC_CHECK_DNS                   1006
#define ID_EXPT                         1006
#define ID_EXPH                         1007
#define ID_LICENSE                      1008
#define IDC_EDIT_LICENSE                1011
#define IDC_EDIT_PHOST                  1012
#define IDC_EDIT_PIP                    1013
#define IDC_EDIT_PSENT                  1014
#define IDC_EDIT_PRECV                  1015
#define IDC_EDIT_PLOSS                  1016
#define IDC_EDIT_PLAST                  1017
#define IDC_EDIT_PBEST                  1018
#define IDC_EDIT_PAVRG                  1019
#define IDC_EDIT_PWORST                 1020
#define IDC_EDIT_PCOMMENT               1021
#define IDC_STATICS                     1022
#define IDC_STATICJ                     1023
#define IDC_COMBO_HOST                  1024
#define IDC_EDIT_MAX_LRU                1025
#define IDC_MFCLINK1                    1026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
